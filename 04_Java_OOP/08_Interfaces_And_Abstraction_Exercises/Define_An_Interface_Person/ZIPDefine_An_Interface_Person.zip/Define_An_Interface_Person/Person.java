package Define_An_Interface_Person;

public interface Person {
    String getName();
    int getAge();
}
