package Border_Control;

public interface Identifiable {
    String getId();
}
