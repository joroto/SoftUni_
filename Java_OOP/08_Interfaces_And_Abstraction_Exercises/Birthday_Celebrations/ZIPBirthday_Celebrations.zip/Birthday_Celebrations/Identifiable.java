package Birthday_Celebrations;

public interface Identifiable {
    String getId();
}
