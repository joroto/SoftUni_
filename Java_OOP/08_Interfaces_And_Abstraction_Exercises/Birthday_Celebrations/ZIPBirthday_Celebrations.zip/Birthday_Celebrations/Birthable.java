package Birthday_Celebrations;

public interface Birthable {
    String getBirthDate();
}
