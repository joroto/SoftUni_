package Food_Shortage;

public interface Person {
    String getName();
    int getAge();
}
