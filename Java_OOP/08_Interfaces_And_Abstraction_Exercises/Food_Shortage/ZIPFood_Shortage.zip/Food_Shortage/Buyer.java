package Food_Shortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
