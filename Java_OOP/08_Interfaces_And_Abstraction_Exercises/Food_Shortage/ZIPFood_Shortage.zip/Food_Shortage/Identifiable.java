package Food_Shortage;

public interface Identifiable {
    String getId();
}
