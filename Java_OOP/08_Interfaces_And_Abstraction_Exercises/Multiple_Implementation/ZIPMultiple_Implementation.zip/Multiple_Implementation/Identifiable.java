package Multiple_Implementation;

public interface Identifiable {
    String getId();
}
