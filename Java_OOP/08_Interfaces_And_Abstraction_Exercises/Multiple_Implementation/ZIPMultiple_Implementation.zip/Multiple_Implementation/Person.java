package Multiple_Implementation;

public interface Person {
    String getName();
    int getAge();
}
