package Multiple_Implementation;

public interface Birthable {
    String getBirthDate();
}
