package Car_Shop_Extend;

public interface Sellable {
    Double getPrice();
}
