package Car_Shop_Extend;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
