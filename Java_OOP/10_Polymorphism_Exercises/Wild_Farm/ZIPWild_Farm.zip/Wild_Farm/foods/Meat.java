package Wild_Farm.foods;

import Wild_Farm.Food;

public class Meat extends Food {
    public Meat(int quantity) {
        super(quantity);
    }
}
