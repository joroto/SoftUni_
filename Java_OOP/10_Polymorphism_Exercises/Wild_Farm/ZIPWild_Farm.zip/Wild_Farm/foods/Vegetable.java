package Wild_Farm.foods;

import Wild_Farm.Food;

public class Vegetable extends Food {
    public Vegetable(int quantity) {
        super(quantity);
    }
}
