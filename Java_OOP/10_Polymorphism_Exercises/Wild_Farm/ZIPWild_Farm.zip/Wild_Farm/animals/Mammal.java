package Wild_Farm.animals;

import Wild_Farm.Animal;

public abstract class Mammal extends Animal {

    protected Mammal(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

}
