package Wild_Farm.animals;

public abstract class Felime extends Mammal{
    private String breed;
    protected Felime(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

}
