package Cards_With_Power;

public class Card {
}
