package Multiple_Inheritance;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        Puppy puppy = new Puppy();

        dog.eat();
        dog.bark();
        puppy.weep();
    }
}

