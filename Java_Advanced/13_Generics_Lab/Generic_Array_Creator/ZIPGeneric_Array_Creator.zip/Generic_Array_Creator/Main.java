package Generic_Array_Creator;

public class Main {
    public static void main(String[] args) {
         Integer[] array = ArrayCreator.create(13,13);
         String[] array2 = ArrayCreator.create(3, "Hello");

    }
}
